import React, { useState, useEffect } from 'react';
import { User, Task, AppView } from './types';
import { getUser, getTasks, saveTasks } from './services/mockBackend';
import SyllabusImport from './components/SyllabusImport';
import FocusRoom from './components/FocusRoom';
import { Flame, Trophy, Plus, BookOpen, Clock, AlertOctagon, ArrowLeft } from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.DASHBOARD);
  const [user, setUser] = useState<User>(getUser());
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTask, setActiveTask] = useState<Task | null>(null);

  useEffect(() => {
    setTasks(getTasks());
    // Poll user stats for updates during session
    const interval = setInterval(() => {
        setUser(getUser());
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleTaskImport = (newTasks: Task[]) => {
    const updated = [...tasks, ...newTasks];
    setTasks(updated);
    saveTasks(updated);
    setView(AppView.DASHBOARD);
  };

  const startSession = (task: Task) => {
    setActiveTask(task);
    setView(AppView.FOCUS_ROOM);
  };

  // --- Views ---

  if (view === AppView.FOCUS_ROOM && activeTask) {
    return (
        <FocusRoom 
            user={user} 
            activeTask={activeTask} 
            onExit={() => {
                setActiveTask(null);
                setView(AppView.DASHBOARD);
            }} 
        />
    );
  }

  if (view === AppView.IMPORT) {
      return (
          <div className="min-h-screen bg-zinc-950 text-white p-4 flex items-center justify-center">
              <SyllabusImport 
                onImport={handleTaskImport}
                onCancel={() => setView(AppView.DASHBOARD)}
              />
          </div>
      );
  }

  // --- Dashboard View ---

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 pb-20 md:pb-0">
      
      {/* Top Bar */}
      <header className="sticky top-0 z-10 bg-zinc-900/80 backdrop-blur-md border-b border-zinc-800 p-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
            <div className="bg-indigo-600 p-1.5 rounded">
                <AlertOctagon size={20} className="text-white" />
            </div>
            <h1 className="font-bold text-xl tracking-tight">Bully.ai</h1>
        </div>
        <div className="flex items-center gap-4">
            <div className="flex items-center gap-1 text-orange-500">
                <Flame size={18} fill="currentColor" />
                <span className="font-bold">{user.streak}</span>
            </div>
            <div className="flex items-center gap-1 text-yellow-500">
                <Trophy size={18} />
                <span className="font-bold">{user.focusScore}</span>
            </div>
            <img 
                src={user.avatarUrl} 
                alt="User" 
                className="w-8 h-8 rounded-full border border-zinc-700"
            />
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4">
        
        {/* Hero Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-gradient-to-br from-indigo-900 to-indigo-950 p-6 rounded-2xl border border-indigo-800/50">
                <h3 className="text-indigo-200 text-sm font-medium mb-1">Next Review</h3>
                <p className="text-3xl font-bold text-white">2 hrs</p>
                <p className="text-xs text-indigo-400 mt-2">Until Chem Midterm</p>
            </div>
            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
                 <h3 className="text-zinc-400 text-sm font-medium mb-1">Global Rank</h3>
                 <p className="text-3xl font-bold text-white">#1,204</p>
                 <p className="text-xs text-red-400 mt-2">Dropped 4 spots today</p>
            </div>
            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-zinc-800 transition-colors group" onClick={() => setView(AppView.IMPORT)}>
                 <div className="w-10 h-10 bg-zinc-800 rounded-full flex items-center justify-center mb-2 group-hover:bg-zinc-700">
                    <Plus size={20} className="text-zinc-400 group-hover:text-white" />
                 </div>
                 <p className="text-sm font-medium text-zinc-300">Import Syllabus</p>
            </div>
        </div>

        {/* Task Board */}
        <div>
            <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
                <BookOpen size={20} className="text-indigo-500" />
                Quest Board
            </h2>

            <div className="space-y-3">
                {tasks.length === 0 ? (
                    <div className="text-center py-12 bg-zinc-900/50 rounded-xl border border-zinc-800 border-dashed">
                        <p className="text-zinc-500 mb-4">No pain, no gain. Import your syllabus to start.</p>
                        <button 
                            onClick={() => setView(AppView.IMPORT)}
                            className="bg-zinc-100 text-black px-6 py-2 rounded-full font-bold hover:scale-105 transition-transform"
                        >
                            Upload .CSV
                        </button>
                    </div>
                ) : (
                    tasks.map(task => (
                        <div 
                            key={task.id} 
                            className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 p-4 rounded-xl flex items-center justify-between transition-all group cursor-pointer"
                            onClick={() => startSession(task)}
                        >
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 bg-zinc-950 rounded-lg flex flex-col items-center justify-center border border-zinc-800">
                                    <span className="text-xs font-bold text-zinc-500">{new Date(task.date).getDate()}</span>
                                    <span className="text-[10px] text-zinc-600 uppercase">{new Date(task.date).toLocaleString('default', { month: 'short' })}</span>
                                </div>
                                <div>
                                    <div className="flex items-center gap-2">
                                        <span className="text-xs font-bold px-2 py-0.5 bg-indigo-900/50 text-indigo-300 rounded border border-indigo-900/50">
                                            {task.courseCode}
                                        </span>
                                    </div>
                                    <h3 className="font-bold text-white mt-1">{task.title}</h3>
                                </div>
                            </div>
                            <div className="flex items-center gap-4">
                                <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center text-indigo-400 gap-1 text-sm font-medium">
                                    Enter Lounge <ArrowLeft className="rotate-180" size={16} />
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
      </main>
    </div>
  );
};

export default App;