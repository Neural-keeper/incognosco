import React, { useState } from 'react';
import Papa from 'papaparse';
import { Task } from '../types';
import { Save, FileText, AlertCircle } from 'lucide-react';

interface Props {
  onImport: (tasks: Task[]) => void;
  onCancel: () => void;
}

const SyllabusImport: React.FC<Props> = ({ onImport, onCancel }) => {
  const [csvText, setCsvText] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleParse = () => {
    if (!csvText.trim()) {
        setError("Please paste your CSV content first.");
        return;
    }

    Papa.parse(csvText, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        if (results.errors.length > 0) {
          setError("Failed to parse CSV. Ensure headers are: Date, Task, Course.");
          return;
        }

        // Map CSV rows to Task objects
        // Expected Format: Date, Task, Course
        const parsedTasks: Task[] = results.data.map((row: any, index) => ({
          id: `imported_${Date.now()}_${index}`,
          title: row.Task || row.task || 'Untitled Task',
          courseCode: row.Course || row.course || 'GEN101',
          date: row.Date || row.date || new Date().toISOString().split('T')[0],
          completed: false,
        }));

        if (parsedTasks.length === 0) {
            setError("No valid tasks found.");
            return;
        }

        onImport(parsedTasks);
      },
      error: (err) => {
        setError(err.message);
      }
    });
  };

  const exampleCSV = `Date,Task,Course
2023-10-27,Read Chapter 4,BIO101
2023-10-28,Submit Lab Report,CHEM200
2023-10-29,Midterm Exam,MATH101`;

  return (
    <div className="p-6 max-w-2xl mx-auto bg-zinc-900 rounded-xl border border-zinc-800 shadow-2xl">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-indigo-600 rounded-lg">
            <FileText className="text-white w-6 h-6" />
        </div>
        <div>
            <h2 className="text-2xl font-bold text-white">Import Syllabus</h2>
            <p className="text-zinc-400 text-sm">Paste your course schedule CSV below.</p>
        </div>
      </div>

      <div className="mb-4">
        <label className="block text-xs font-mono text-zinc-500 mb-2 uppercase">CSV Format Example</label>
        <pre className="bg-zinc-950 p-3 rounded border border-zinc-800 text-xs text-zinc-400 font-mono select-all">
            {exampleCSV}
        </pre>
      </div>

      <textarea
        className="w-full h-48 bg-zinc-950 text-white p-4 rounded-lg border border-zinc-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-mono text-sm"
        placeholder="Paste CSV data here..."
        value={csvText}
        onChange={(e) => setCsvText(e.target.value)}
      />

      {error && (
        <div className="mt-4 p-3 bg-red-900/30 border border-red-800 rounded text-red-200 text-sm flex items-center gap-2">
          <AlertCircle size={16} />
          {error}
        </div>
      )}

      <div className="flex justify-end gap-3 mt-6">
        <button 
            onClick={onCancel}
            className="px-4 py-2 text-zinc-400 hover:text-white transition-colors"
        >
            Cancel
        </button>
        <button
          onClick={handleParse}
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg font-medium transition-all"
        >
          <Save size={18} />
          Sync Schedule
        </button>
      </div>
    </div>
  );
};

export default SyllabusImport;