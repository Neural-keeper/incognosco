import React, { useEffect, useRef, useState, useCallback } from 'react';
import { User, Task, Message } from '../types';
import { generateRoast } from '../services/geminiService';
import { sendMessage, getMessages, simulatePeerActivity, updateUserScore } from '../services/mockBackend';
import { ArrowLeft, Eye, EyeOff, Send, AlertTriangle, PhoneOff } from 'lucide-react';

// Global TS definition for loaded scripts
declare global {
  interface Window {
    cocoSsd: any;
    tf: any;
  }
}

interface Props {
  user: User;
  activeTask: Task;
  onExit: () => void;
}

const FocusRoom: React.FC<Props> = ({ user, activeTask, onExit }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [isPhoneDetected, setIsPhoneDetected] = useState(false);
  const [model, setModel] = useState<any>(null);
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes in seconds
  const [cameraError, setCameraError] = useState(false);
  const requestRef = useRef<number>();

  // --- Setup & AI ---

  useEffect(() => {
    // Load Messages
    setMessages(getMessages(activeTask.courseCode));
    
    // Peer Simulation
    const cleanupPeers = simulatePeerActivity(activeTask.courseCode, (newMsg) => {
        setMessages(prev => [...prev, newMsg]);
    });

    // Load AI Model
    const loadModel = async () => {
      if (window.cocoSsd) {
        try {
          const loadedModel = await window.cocoSsd.load();
          setModel(loadedModel);
        } catch (err) {
          console.error("Failed to load model", err);
        }
      }
    };
    loadModel();

    return () => {
        cleanupPeers();
        cancelAnimationFrame(requestRef.current!);
    };
  }, [activeTask.courseCode]);

  // --- Webcam Logic ---

  const startWebcam = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480 } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
             videoRef.current?.play();
             setIsMonitoring(true);
             detectFrame();
        };
      }
    } catch (err) {
      console.error("Camera denied", err);
      setCameraError(true);
    }
  }, []);

  const stopWebcam = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach(track => track.stop());
    }
    setIsMonitoring(false);
    cancelAnimationFrame(requestRef.current!);
  }, []);

  // --- Detection Loop ---

  const lastDetectionTime = useRef<number>(0);
  const cooldownRef = useRef(false);

  const detectFrame = async () => {
    if (!model || !videoRef.current || cooldownRef.current) return;

    // Throttling detection to every 500ms to save battery/performance
    const now = Date.now();
    if (now - lastDetectionTime.current < 500) {
         requestRef.current = requestAnimationFrame(detectFrame);
         return;
    }
    lastDetectionTime.current = now;

    try {
      const predictions = await model.detect(videoRef.current);
      
      // Check for "cell phone"
      const phone = predictions.find((p: any) => p.class === 'cell phone' && p.score > 0.6);

      if (phone) {
        handlePhoneDetected();
      } else {
        setIsPhoneDetected(false);
      }
    } catch (err) {
      console.warn("Prediction error", err);
    }
    
    if (isMonitoring) {
        requestRef.current = requestAnimationFrame(detectFrame);
    }
  };

  const handlePhoneDetected = async () => {
    setIsPhoneDetected(true);
    cooldownRef.current = true; // Stop detecting while we process the roast

    // 1. Play sound (optional/simulated here)
    // 2. Generate Roast
    const roastText = await generateRoast(user.name, activeTask.title);

    // 3. Post to Chat
    const roastMsg: Message = {
        id: Date.now().toString(),
        userId: 'SYSTEM_AI',
        userName: '🤖 ROAST BOT',
        content: roastText,
        timestamp: Date.now(),
        isRoast: true,
        courseCode: activeTask.courseCode
    };
    
    sendMessage(roastMsg);
    setMessages(prev => [...prev, roastMsg]);

    // 4. Penalty
    updateUserScore(50);

    // 5. Reset cooldown after 10 seconds so we don't spam roasts every frame
    setTimeout(() => {
        cooldownRef.current = false;
        setIsPhoneDetected(false);
        // Restart loop if still monitoring
        if (isMonitoring) requestRef.current = requestAnimationFrame(detectFrame);
    }, 10000);
  };

  // --- Chat Logic ---

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newMsg: Message = {
      id: Date.now().toString(),
      userId: user.id,
      userName: user.name,
      content: inputValue,
      timestamp: Date.now(),
      isRoast: false,
      courseCode: activeTask.courseCode
    };

    sendMessage(newMsg);
    setMessages(prev => [...prev, newMsg]);
    setInputValue('');
  };

  // --- Timer Logic ---
  
  useEffect(() => {
      let interval: any;
      if (isMonitoring && timeLeft > 0) {
          interval = setInterval(() => setTimeLeft(t => t - 1), 1000);
      } else if (timeLeft === 0) {
          setIsMonitoring(false);
          stopWebcam();
      }
      return () => clearInterval(interval);
  }, [isMonitoring, timeLeft, stopWebcam]);

  const formatTime = (sec: number) => {
      const m = Math.floor(sec / 60);
      const s = sec % 60;
      return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="flex flex-col h-full bg-black text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-zinc-900 border-b border-zinc-800">
        <button onClick={() => { stopWebcam(); onExit(); }} className="text-zinc-400 hover:text-white">
          <ArrowLeft />
        </button>
        <div className="text-center">
            <h2 className="font-bold text-lg">{activeTask.courseCode} Lounge</h2>
            <p className="text-xs text-zinc-500">{activeTask.title}</p>
        </div>
        <div className={`font-mono text-xl font-bold ${isPhoneDetected ? 'text-red-500 animate-pulse' : 'text-indigo-400'}`}>
            {formatTime(timeLeft)}
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        
        {/* Left: Surveillance Feed (Hidden on small mobile, prominent on desktop) */}
        <div className="hidden md:flex flex-col w-1/3 bg-zinc-950 border-r border-zinc-800 p-4 relative">
             <div className="relative w-full aspect-video bg-zinc-900 rounded-lg overflow-hidden border-2 border-zinc-800">
                {!isMonitoring && !cameraError && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-zinc-500">
                        <EyeOff size={48} className="mb-2"/>
                        <p>Surveillance Inactive</p>
                    </div>
                )}
                {cameraError && (
                     <div className="absolute inset-0 flex flex-col items-center justify-center text-red-500">
                     <AlertTriangle size={48} className="mb-2"/>
                     <p>Camera Access Denied</p>
                 </div>
                )}
                <video 
                    ref={videoRef} 
                    className={`w-full h-full object-cover transform scale-x-[-1] ${isPhoneDetected ? 'border-4 border-red-600' : ''}`} 
                    muted 
                    playsInline
                />
                
                {isPhoneDetected && (
                    <div className="absolute top-0 left-0 w-full h-full bg-red-500/20 flex items-center justify-center z-10 animate-pulse">
                        <div className="bg-red-600 text-white px-6 py-3 rounded-full font-black text-xl shadow-xl border-4 border-white">
                            PHONE DETECTED
                        </div>
                    </div>
                )}

                <div className="absolute top-4 left-4 bg-black/50 px-2 py-1 rounded text-xs font-mono text-green-400 flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${isMonitoring ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
                    {isMonitoring ? 'AI MONITORING: ACTIVE' : 'OFFLINE'}
                </div>
             </div>

             <div className="mt-8 text-center">
                {!isMonitoring ? (
                    <button 
                        onClick={startWebcam}
                        className="w-full py-4 bg-green-600 hover:bg-green-700 text-white font-bold rounded-xl transition-all shadow-[0_0_20px_rgba(34,197,94,0.3)]"
                    >
                        START SESSION
                    </button>
                ) : (
                    <div className="space-y-4">
                        <p className="text-zinc-400 text-sm">
                            Put your phone away. The AI is watching. 
                            If you pick it up, you will be roasted publicly.
                        </p>
                        <div className="flex justify-center gap-4 text-xs font-mono text-zinc-600">
                            <span>Model: COCO-SSD</span>
                            <span>Backend: TFJS WebGL</span>
                        </div>
                    </div>
                )}
             </div>
        </div>

        {/* Right: Chat Area */}
        <div className="flex-1 flex flex-col bg-zinc-950 relative">
            {/* Mobile Video Preview (Floating) */}
            {isMonitoring && (
                <div className="md:hidden absolute top-4 right-4 w-24 h-32 bg-black rounded-lg border border-zinc-700 overflow-hidden z-20 shadow-xl">
                    <video ref={videoRef} className="w-full h-full object-cover transform scale-x-[-1]" muted playsInline />
                </div>
            )}

            <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex flex-col ${msg.isRoast ? 'items-center' : msg.userId === user.id ? 'items-end' : 'items-start'}`}>
                        {msg.isRoast ? (
                            <div className="w-full max-w-md bg-red-900/20 border border-red-600/50 p-4 rounded-xl text-center my-4 animate-shake">
                                <div className="flex items-center justify-center gap-2 text-red-500 font-bold mb-1 uppercase tracking-widest text-xs">
                                    <AlertTriangle size={14} />
                                    Distraction Alert
                                </div>
                                <p className="text-red-200 font-medium italic">"{msg.content}"</p>
                                <p className="text-xs text-red-500/50 mt-2 font-mono uppercase">Focus Score -50</p>
                            </div>
                        ) : (
                            <div className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                                msg.userId === user.id 
                                    ? 'bg-indigo-600 text-white rounded-tr-none' 
                                    : 'bg-zinc-800 text-zinc-200 rounded-tl-none'
                            }`}>
                                <p className="text-xs font-bold opacity-50 mb-0.5">{msg.userName}</p>
                                <p>{msg.content}</p>
                            </div>
                        )}
                    </div>
                ))}
                {messages.length === 0 && (
                    <div className="h-full flex flex-col items-center justify-center text-zinc-700">
                        <PhoneOff size={48} className="mb-4 opacity-20" />
                        <p>Quiet in here... Start focusing.</p>
                    </div>
                )}
            </div>

            {/* Input */}
            <form onSubmit={handleSend} className="p-4 bg-zinc-900 border-t border-zinc-800 flex gap-2">
                <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder={isMonitoring ? "Type message..." : "Start session to chat..."}
                    disabled={!isMonitoring}
                    className="flex-1 bg-zinc-950 border border-zinc-700 rounded-full px-4 py-2 focus:outline-none focus:border-indigo-500 text-white transition-colors disabled:opacity-50"
                />
                <button 
                    type="submit" 
                    disabled={!inputValue || !isMonitoring}
                    className="p-2 bg-indigo-600 rounded-full text-white disabled:bg-zinc-800 disabled:text-zinc-500 transition-colors"
                >
                    <Send size={20} />
                </button>
            </form>
        </div>

      </div>
    </div>
  );
};

export default FocusRoom;