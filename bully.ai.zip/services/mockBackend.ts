import { User, Task, Message } from '../types';

// Mock Data Initializers
const CURRENT_USER_ID = 'user_1';
const MOCK_USER: User = {
  id: CURRENT_USER_ID,
  name: 'Alex Student',
  avatarUrl: 'https://picsum.photos/seed/alex/200',
  streak: 4,
  focusScore: 850,
};

const INITIAL_TASKS: Task[] = [
  { id: '1', title: 'Study for Chem Midterm', courseCode: 'CHEM101', date: '2023-10-25', completed: false },
  { id: '2', title: 'Calculus Problem Set', courseCode: 'MATH200', date: '2023-10-26', completed: false },
];

const INITIAL_MESSAGES: Message[] = [
  { id: 'm1', userId: 'user_2', userName: 'Sarah', content: 'Anyone barely passing Chem right now?', timestamp: Date.now() - 100000, isRoast: false, courseCode: 'CHEM101' },
  { id: 'm2', userId: 'user_3', userName: 'Mike', content: 'I have no idea what is going on.', timestamp: Date.now() - 90000, isRoast: false, courseCode: 'CHEM101' },
];

// LocalStorage Keys
const KEY_TASKS = 'bully_ai_tasks';
const KEY_MESSAGES = 'bully_ai_messages';
const KEY_USER = 'bully_ai_user';

// Helpers
const getStored = <T,>(key: string, initial: T): T => {
  const saved = localStorage.getItem(key);
  return saved ? JSON.parse(saved) : initial;
};

const setStored = <T,>(key: string, data: T) => {
  localStorage.setItem(key, JSON.stringify(data));
};

// Exports
export const getUser = (): User => getStored(KEY_USER, MOCK_USER);

export const updateUserScore = (penalty: number) => {
  const user = getUser();
  user.focusScore = Math.max(0, user.focusScore - penalty);
  user.streak = 0; // Reset streak on fail
  setStored(KEY_USER, user);
  return user;
};

export const getTasks = (): Task[] => getStored(KEY_TASKS, INITIAL_TASKS);

export const saveTasks = (tasks: Task[]) => setStored(KEY_TASKS, tasks);

export const getMessages = (courseCode: string): Message[] => {
  const allMessages = getStored(KEY_MESSAGES, INITIAL_MESSAGES);
  return allMessages
    .filter(m => m.courseCode === courseCode)
    .sort((a, b) => a.timestamp - b.timestamp);
};

export const sendMessage = (msg: Message) => {
  const all = getStored(KEY_MESSAGES, INITIAL_MESSAGES);
  all.push(msg);
  // Ephemeral check: Remove messages older than 24 hours (mocking TTL)
  const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
  const filtered = all.filter(m => m.timestamp > oneDayAgo);
  setStored(KEY_MESSAGES, filtered);
};

export const simulatePeerActivity = (courseCode: string, callback: (msg: Message) => void) => {
  // Occasionally simulate a peer sending a message
  const interval = setInterval(() => {
    if (Math.random() > 0.8) {
        const names = ['Sarah', 'Mike', 'Jessica', 'David'];
        const texts = ['Focus up guys.', 'This is impossible.', 'Wait, is the exam tomorrow?', 'My brain hurts.'];
        const randomName = names[Math.floor(Math.random() * names.length)];
        const randomText = texts[Math.floor(Math.random() * texts.length)];
        
        const msg: Message = {
            id: Date.now().toString(),
            userId: `peer_${Date.now()}`,
            userName: randomName,
            content: randomText,
            timestamp: Date.now(),
            isRoast: false,
            courseCode
        };
        sendMessage(msg);
        callback(msg);
    }
  }, 8000);
  return () => clearInterval(interval);
};