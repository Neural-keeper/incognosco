import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY || '';

// Initialize securely
let ai: GoogleGenAI | null = null;
if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
}

export const generateRoast = async (userName: string, taskName: string): Promise<string> => {
  if (!ai) {
    return `🚨 ALERT: ${userName} failed Focus Mode. Shame them! (AI Key Missing)`;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are a ruthless, sarcastic, and mean AI study monitor. 
      The user named "${userName}" was supposed to be focusing on "${taskName}" but was just caught by the webcam looking at their phone.
      
      Write a short, public humiliation message (max 2 sentences) to be broadcast to their study group. 
      Roast them for having no discipline. Make it sound like a "System Alert".
      Do not use hashtags.`,
    });

    return response.text || `🚨 ALERT: ${userName} is distracted. Boo this person!`;
  } catch (error) {
    console.error("Failed to generate roast", error);
    return `🚨 ALERT: ${userName} was caught slacking off!`;
  }
};